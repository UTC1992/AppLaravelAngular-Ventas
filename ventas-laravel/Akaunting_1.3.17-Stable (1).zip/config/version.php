<?php

return [

    'name'      =>  'Akaunting',

    'code'      =>  'Reconciliation',

    'major'     =>  '1',

    'minor'     =>  '3',

    'patch'     =>  '17',

    'build'     =>  '',

    'status'    =>  'Stable',

    'date'      =>  '10-April-2019',

    'time'      =>  '21:45',

    'zone'      =>  'GMT +3',

];
